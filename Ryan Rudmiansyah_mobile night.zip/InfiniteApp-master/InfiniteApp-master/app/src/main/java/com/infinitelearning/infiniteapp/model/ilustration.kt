package com.infinitelearning.infiniteapp.model

data class ilustration(
    val id: Int,
    val name: String,
    val photo: Int,
)
