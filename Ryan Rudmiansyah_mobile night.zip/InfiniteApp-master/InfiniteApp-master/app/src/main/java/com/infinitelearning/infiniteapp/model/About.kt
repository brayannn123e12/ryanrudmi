package com.infinitelearning.infiniteapp.model

data class About(
    val id: Int,
    val name: String,
    val email: String,
    val asalperguruan: String,
    val jurusan: String,
    val photo: Int,
)