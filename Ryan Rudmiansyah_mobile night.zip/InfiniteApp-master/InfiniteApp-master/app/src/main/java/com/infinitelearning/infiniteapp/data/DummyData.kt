package com.infinitelearning.infiniteapp.data

import com.infinitelearning.infiniteapp.R
import com.infinitelearning.infiniteapp.model.About
import com.infinitelearning.infiniteapp.model.ilustration
import com.infinitelearning.infiniteapp.model.servant
import com.infinitelearning.infiniteapp.model.teacher

object DummyData {
    val mobileTeachers = listOf(
        teacher(
            id = 1,
            name = "bacaran",
            nickname = "baba",
            role = "teacher ilustation",
            photo = R.drawable.png_transparent_the_son_of_man_the_great_war_magritte_paintings_le_modele_rouge_surrealism_painting_painting_surrealism_art_thumbnail
        ),
        teacher(
            id = 2,
            name = "bahamot",
            nickname = "amot",
            role = "Teacher ilustation ",
            photo = R.drawable.chelovek_v_kotelke
        ),
        teacher(
            id = 3,
            name = "rogue",
            nickname = "rogue",
            role = "Teacher ilustation",
            photo = R.drawable._54_012_0105_111magritte_6986l_reshot_a1_2000x1599_4263792285_52084_567167691
        ),
        teacher(
            id = 4,
            name = "steven",
            nickname = "even",
            role = "Teacher ilustation",
            photo = R.drawable._f19f3
        ),
        teacher(
            id = 5,
            name = "araamorr",
            nickname = "amorr",
            role = "Teacher ilustation",
            photo = R.drawable._146159
        )
    )

    val mobileServants = listOf(
        servant(
            id = 1,
            name = "Ferry",
            photo = R.drawable.no_profile,
            batch = "1000",
            role = "student ilustation",
        ),
        servant(
            id = 2,
            name = "maria",
            photo = R.drawable.no_profile,
            batch = "1000",
            role = "student ilustation",
        ),
        servant(
            id = 3,
            name = "farhan",
            photo = R.drawable.no_profile,
            batch = "1000",
            role = "student ilustation",
        ),
        servant(
            id = 4,
            name = "shopie",
            photo = R.drawable.no_profile,
            batch = "1000",
            role = "student ilustation",
        ),
        servant(
            id = 5,
            name = "ajax",
            photo = R.drawable.no_profile,
            batch = "1000",
            role = "student ilustation",
        ),
        servant(
            id = 6,
            name = "louve",
            photo = R.drawable.no_profile,
            batch = "1000",
            role = "student ilustation",
        ),
        servant(
            id = 7,
            name = "peter",
            photo = R.drawable.no_profile,
            batch = "1000",
            role = "student ilustation",
        ),
        servant(
            id = 8,
            name = "bryan",
            photo = R.drawable.no_profile,
            batch = "1000",
            role = "student ilustation",
        ),
        servant(
            id = 9,
            name = "angel",
            photo = R.drawable.no_profile,
            batch = "1000",
            role = "student ilustation",
        ),
        servant(
            id = 10,
            name = "aramai",
            photo = R.drawable.no_profile,
            batch = "1000",
            role = "student ilustation",
        )
    )

    val mobileCours = listOf(
        About(
            id = 1,
            name = "Kotlin Introduction",
            email = "214201000@dinamika.ac.id",
            asalperguruan = "universitas dinamika",
            jurusan ="desain komunikasi visual" ,
            photo = R.drawable.kotlin_introduction
        )
    )

    val infiniteGalleries = listOf(
        ilustration(
            id = 1,
            name = "seorang seniman",
            photo = R.drawable.download__1_
        ),
        ilustration(
            id = 2,
            name = "pengoleksi seni",
            photo = R.drawable.download
        ),
        ilustration(
            id = 3,
            name = "suka lukisan abstrak",
            photo = R.drawable.download__2_
        ),
        ilustration(
            id = 4,
            name = "kolektor",
            photo = R.drawable.chelovek_v_kotelke
        ),
        ilustration(
            id = 5,
            name = "seniman realisme",
            photo = R.drawable._00px_the_persistence_of_memory
        ),
        ilustration(
            id = 6,
            name = "pemilik museum",
            photo = R.drawable.close_the_light_daria_shcherba
        ),
        ilustration(
            id = 7,
            name = "pencinta seni lukis",
            photo = R.drawable.images__2_
        ),
        ilustration(
            id = 8,
            name = "seniman surialisme",
            photo = R.drawable.images__1_
        ),
        ilustration(
            id = 9,
            name = "Kritikus seni",
            photo = R.drawable.paysage_en_forme_de_poisson_1941_karya_andre_masson
        ),
        ilustration(
            id = 10,
            name = "tidak suka seni",
            photo = R.drawable._332234892_prepyatstvie_pustoti
        ),
    )
}