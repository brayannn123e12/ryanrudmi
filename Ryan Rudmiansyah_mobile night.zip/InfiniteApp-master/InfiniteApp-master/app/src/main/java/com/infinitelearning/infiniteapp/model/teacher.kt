package com.infinitelearning.infiniteapp.model

data class teacher(
    val id: Int,
    val name: String,
    val nickname: String,
    val role: String,
    val photo: Int,
)
