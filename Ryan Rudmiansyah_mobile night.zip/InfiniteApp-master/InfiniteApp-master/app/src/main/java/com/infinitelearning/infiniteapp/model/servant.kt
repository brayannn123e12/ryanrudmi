package com.infinitelearning.infiniteapp.model

data class servant(
    val id: Int,
    val name: String,
    val photo: Int,
    val batch: String,
    val role: String,
)